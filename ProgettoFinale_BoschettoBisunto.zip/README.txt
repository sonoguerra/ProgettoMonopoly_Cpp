NOTE:
Il main gestisce esclusivamente la scrittura su terminale mentre le altre classi di cui vengono chiamate le funzioni (nello specifico Board e Player) gestiscono la scrittura su file.